New Relic PHP Agent

For installation instructions, INI file settings, 
and API descriptions please see the online FAQ at:
    http://newrelic.com/docs/php/new-relic-for-php

For license and copyright, see LICENSE.txt.

For support, contact us at http://support.newrelic.com for assistance.
